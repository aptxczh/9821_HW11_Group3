#include "Option_Base.hpp"

option_base::option_base(double spot, double strike, double vol, double drift, double interest, double maturity,double q,char new_t):S0(spot),
k(strike), sigma(vol), mu(drift),r(interest),T(maturity),dividend(q),type(new_t){}

option_base::~option_base(){}

option_base::option_base(const option_base& new_opt) : S0(new_opt.S0),k(new_opt.k), sigma(new_opt.sigma), 
mu(new_opt.mu), r(new_opt.r), T(new_opt.T),dividend(new_opt.dividend), type(new_opt.type) {}

option_base& option_base::operator=(const option_base& new_opt) {
	if (this == &new_opt) {
		return *this;
	}

	S0 = new_opt.S0;
	k = new_opt.k;
	sigma = new_opt.sigma;
	mu = new_opt.mu;
	r = new_opt.r;
	T = new_opt.T;
	type = new_opt.type;
	dividend = new_opt.dividend;

	return *this;
}