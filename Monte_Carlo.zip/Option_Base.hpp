#ifndef OPTION_BASE_HPP
#define OPTION_BASE_HPP
#include "Random_Number_Generator.hpp"
class option_base {

public:
	double S0;
	double k;
	double sigma;
	double mu;
	double r;
	double T;
	double dividend;
	char type;
	option_base(double spot=0,double strike=0, double vol=0, double drift=0, double interest=0, double maturity=0, double q=0, char new_type='c');
	virtual ~option_base();
	option_base(const option_base& new_opt);
	option_base& operator=(const option_base& new_opt);

};

#endif