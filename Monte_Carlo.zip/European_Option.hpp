#ifndef EUROPEAN_OPTION_HPP
#define	EUROPEAN_OPTION_HPP
#include "Option_Base.hpp"
#include <tuple>
class european_option:public option_base {
public:
	double d1;
	double d2;
	european_option(double spot = 0, double strike = 0, double vol = 0, double drift = 0, double interest = 0, double maturity = 1, double q = 0, char new_type='c');
	european_option(const european_option& new_eopt);
	virtual ~european_option();
	european_option& operator=(const european_option& new_eopt);
	double BS_price();
	double BS_delta();
	double BS_vega();
	//return type is a vector, because we also return delta, vega
	virtual std::vector<double> MC_pricer(int n,char eigen);
	virtual void Contral_Variance();
	virtual void Anti_Vari();
	double central_product(std::vector<double> b1,std::vector<double> b2);
	virtual void Moment_Matching();
};

class euoption_disdiv :public european_option {
public:
	std::vector<std::tuple<double, double, bool>> time_div; //with the first element to be (0,0,0) for convenience
	euoption_disdiv(std::vector<std::tuple<double, double,bool>> dividend,double spot = 0, double strike = 0, double vol = 0, double drift = 0, double interest = 0, double maturity = 1 , double q=0,char new_type = 'c');
	euoption_disdiv(const euoption_disdiv& new_eopt);
	virtual std::vector<double> MC_pricer(int n, char eigen) override;
	virtual std::vector<double> Control_Variance(int N, char eigen);
	virtual ~euoption_disdiv();
	euoption_disdiv& operator=(const euoption_disdiv& new_eopt);
};


#endif