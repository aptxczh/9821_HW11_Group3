#include "Random_Number_Generator.hpp"
#include "European_Option.hpp"
#include "Basket_Option.hpp"
#include<fstream>
#include<iomanip>
#include<string>
template <typename T>
void Print_vector(std::vector<T> vec);
template <typename T>
void Output_vector(const std::vector<T>vec, const std::string& filename);
void problem1();
void problem2();
int main() {


	/*problem1();
	getchar();
	getchar();*/
	problem2();
	return 0;
}

template <typename T>
void Print_vector(std::vector<T> vec) {
	for (auto it = vec.begin(); it != vec.end(); it++) {
		std::cout << *it << '\t' ;
	}
}
template <typename T>
void Output_vector(const std::vector<T>vec, const std::string& filename){
	std::ofstream file;
	file.open(filename, std::ios_base::app);
	file << std::fixed << std::setprecision(9);
	for (auto i : vec) {
		file << i << ',';
	}
	file << "\n";
	file.close();
}
void problem1() {
	Basket_Option B1(25,50,0.3,0.05,0.05,0.5,0,'c',0.2,0.35,30);
	european_option C1(50, 55, 0.3, 0.04, 0.04, 0.5, 0, 'p');
	std::cout << std::setprecision(15);
		
	C1.Anti_Vari();

}
void problem2() {
	std::vector<std::tuple<double, double, bool>> time_div;
	time_div.push_back(std::make_tuple(0.0, 0.0, 0));
	time_div.push_back(std::make_tuple(2.0 / 12, 0.5, 0));
	time_div.push_back(std::make_tuple(4.0 / 12, 0.01, 1));
	time_div.push_back(std::make_tuple(6.0 / 12, 0.75, 0));
	euoption_disdiv P1(time_div, 50, 55.55, 0.3, 0, 0.02, 7.0 / 12, 0, 'p');
	for (long long num = 10000; num <= 2560000; num *= 2) {
		Output_vector(P1.MC_pricer(4*num, 'B'), "result.csv");
		std::cout << num << std::endl;
	}
	for (long long num = 10000; num <= 1280000; num *= 2) {
		Output_vector(P1.Control_Variance(4*num, 'B'), "result.csv");
		std::cout << num << std::endl;
	}
	//Print_vector(P1.Control_Variance(10000, 'B'),"result.csv");
}