#include "European_Option.hpp"

european_option::european_option(double spot, double strike , double vol , double drift, double interest , double maturity , double q, char new_type ) 
:option_base(spot,strike,vol,drift,interest,maturity, q, new_type){
	d1 = (log(S0 / k) + (r - q + 0.5*pow(sigma, 2))*T) / (sigma*sqrt(T));
	d2 = d1 - sigma*sqrt(T);
}

european_option::~european_option() {}

european_option::european_option(const european_option&  new_eopt):option_base(new_eopt),d1(new_eopt.d1),d2(new_eopt.d2) {}

european_option& european_option::operator=(const european_option&  new_eopt) {
	if (this == &new_eopt) {
		return *this;
	}

	option_base::operator=(new_eopt);
	d1 = new_eopt.d1;
	d2 = new_eopt.d2;
	return *this;
}



double european_option::BS_price() {
	if (type == 'c') {
		return normalCDF(d1)*S0*exp(-dividend*T) - normalCDF(d2)*k*exp(-r*T);
	}
	else {
		return normalCDF(-d2)*k*exp(-r*T) - normalCDF(-d1)*S0*exp(-dividend*T);
	}
}

double european_option::BS_delta() {
	if (type == 'c') {
		return normalCDF(d1)*exp(-dividend*T);
	}
	else {
		return -normalCDF(-d1)*exp(-dividend*T);
	}
}

double european_option::BS_vega() {
	return S0*exp(-dividend*T)*sqrt(T)*normalPDF(d1);
}

std::vector<double> european_option::MC_pricer(int step, char eigen='I') {
	Random_Number_Generator rg(step);
	std::vector<double> normals;
	std::vector<double> option_values;
	std::vector<double> option_deltas;
	std::vector<double> option_vegas;
	std::vector<double> results;
	
	double sum_vals = 0;
	double sum_deltas = 0;
	double sum_vegas = 0;
	int size;
	
	if (eigen == 'I') {
		normals = rg.Invese_Transform_Normal();
	}
	else if (eigen == 'B') {
		normals = rg.Box_Muller_Normal();
	}
	else {
		normals = rg.Acceptance_Rejection_Normal();
	}
	size = normals.size();
	std::vector<double> ST;
	for (auto it = normals.begin(); it != normals.end(); it++) {
		ST.push_back(S0*exp((r-dividend-sigma*sigma/2)*T+sigma*sqrt(T)*(*it)));
	}

	auto it_2 = normals.begin();  //iterator for normal
	if (type == 'c') { //code for call option
		for (auto it = ST.begin(); it != ST.end(); it++) {
			sum_vals += exp(-r*T)*std::max((*it) - k, 0.0);
			sum_deltas+=((*it) >= k)*exp(-r*T)*((*it) / S0);
			sum_vegas+=((*it) >= k)*exp(-r*T)*(*it)*(-sigma*T + sqrt(T)*(*it_2));
			it_2++;
		}
	}
	else
	{	
		for (auto it = ST.begin(); it != ST.end(); it++) {
			sum_vals+=exp(-r*T)*std::max(k - (*it), 0.0);
			sum_deltas+=-((*it) <= k)*exp(-r*T)*((*it) / S0);
			sum_vegas+=-((*it) <= k)*exp(-r*T)*(*it)*(-sigma*T+sqrt(T)*(*it_2));
			it_2++;
		}
	}

	results.push_back(sum_vals / size);
	results.push_back(sum_deltas / size);
	results.push_back(sum_vegas / size);
	return results;
	
}

void european_option::Contral_Variance() {
	Random_Number_Generator rg(7000000);
	//define values
	std::vector<double> normals;
	std::vector<double> stocks;
	std::vector<double> values;
	double temp_value=0;
	double S_t = 0;
	double temp_w = 0;
	double sum_w = 0;
	double mean_w = 0;
	int start_point = 0;
	normals = rg.Box_Muller_Normal();
	double b = 0;

	for (int iteration = 10000; iteration <=5120000; iteration = iteration * 2) {
		for (int i = start_point; i < iteration; ++i) {
			S_t = S0*exp((r - sigma*sigma / 2)*T + sigma*sqrt(T)*normals[i]);
			temp_value = std::max(k-S_t, 0.0)*exp(-r*T);
			stocks.push_back(S_t);
			values.push_back(temp_value);
		}
		b = central_product(stocks, values) / central_product(stocks, stocks);
		sum_w = 0;
		for (int i = 0; i < iteration; ++i) {
			temp_w = values[i] - b*(stocks[i] - exp(r*T)*S0);
			sum_w += temp_w;
		}

		mean_w = sum_w / iteration;
		std::cout << iteration << '\t' << mean_w << '\t'<<abs(BS_price()-mean_w)<<'\n';
		start_point = iteration;
	}


}


double european_option::central_product(std::vector<double> b1, std::vector<double> b2) {
	double result=0;
	double mean_1 = 0;
	double mean_2 = 0;
	double temp_sum_1=0;
	double temp_sum_2 = 0;
	int size = b1.size();

	for (auto it = b1.begin(); it != b1.end(); it++) {
		temp_sum_1 += *it;
	}
	mean_1 = temp_sum_1 / size;
	
	for (auto it = b1.begin(); it != b1.end(); it++) {
		(*it) -= mean_1;
	}

	for (auto it = b2.begin(); it != b2.end(); it++) {
		temp_sum_2 += *it;
	}
	mean_2 = temp_sum_2 / size;

	for (auto it = b2.begin(); it != b2.end(); it++) {
		(*it) -= mean_2;
	}

	for (int i = 0; i < size; ++i) {
		result += b1[i] * b2[i];
	}

	return result;
}

void european_option::Anti_Vari() {
	double S_1 = 0;
	double S_2 = 0;
	double temp_v1 = 0;
	double temp_v2 = 0;
	double sum_value = 0;
	double temp_value = 0;
	double mean_value = 0;

	int start_point = 0;
	Random_Number_Generator rg(5120000);
	//define values
	std::vector<double> normals;
	normals = rg.Invese_Transform_Normal();

	for (int iteration = 10000; iteration <= 5120000; iteration *= 2) {
		for (int i = start_point; i < iteration; ++i) {
			S_1 = S0*exp((r - sigma*sigma / 2)*T + sigma*sqrt(T)*normals[i]);
			temp_v1 = std::max(k - S_1, 0.0)*exp(-r*T);
			S_2 = S0*exp((r - sigma*sigma / 2)*T + sigma*sqrt(T)*(-normals[i]));
			temp_v2 = std::max(k - S_2, 0.0)*exp(-r*T);
			temp_value = (temp_v1 + temp_v2)/2;
			sum_value += temp_value;
		}
		mean_value = sum_value / iteration;
		std::cout << iteration << '\t' << mean_value << '\t'<<abs(BS_price() - mean_value) << '\n';
		start_point = iteration;
	}
}

void european_option::Moment_Matching() {

}


euoption_disdiv::euoption_disdiv(std::vector<std::tuple<double, double, bool>> dividend,double spot, double strike, double vol, double drift, double interest, double maturity, double q, char new_type)
	:european_option(spot, strike, vol, drift, interest, maturity, q, new_type) {
	time_div = dividend;
}

euoption_disdiv::~euoption_disdiv() {}

euoption_disdiv::euoption_disdiv(const euoption_disdiv&  new_eopt) :european_option(new_eopt), time_div(new_eopt.time_div){}

euoption_disdiv& euoption_disdiv::operator=(const euoption_disdiv&  new_eopt) {
	if (this == &new_eopt) {
		return *this;
	}

	european_option::operator=(new_eopt);
	this->time_div = new_eopt.time_div;
	return *this;
}


std::vector<double> euoption_disdiv::MC_pricer(int N, char eigen = 'I') {
	Random_Number_Generator rg(N*2);
	std::vector<double> normals;
	//std::vector<double> option_values;
	//std::vector<double> option_deltas;
	std::vector<double> results;

	double sum_vals = 0;
	double sum_deltas = 0;
	double sum_vegas = 0;

	if (eigen == 'I') {
		normals = rg.Invese_Transform_Normal();
	}
	else if (eigen == 'B') {
		normals = rg.Box_Muller_Normal();
	}
	else {
		normals = rg.Acceptance_Rejection_Normal();
	}	
	int freq = time_div.size()-1;//frequency of dividends

	double factor;
	std::vector<double> ST;
	std::vector<double> ST_tilde;
	double proportional_dividends = 1;
	for (auto ele : time_div) {
		if (std::get<2>(ele) == 1)
			proportional_dividends *= (1 - std::get<1>(ele));
	}
	for (int it = 0; it <=N-freq;it=it+4) {
		double stemp = S0;
		double stilde = S0;
		for (int i = 1; i <= freq; ++i) {
			factor = exp((r - dividend - sigma*sigma / 2)*(std::get<0>(time_div[i]) - std::get<0>(time_div[i - 1]))
				+ sigma*sqrt(std::get<0>(time_div[i]) - std::get<0>(time_div[i - 1]))*normals[it + i - 1]);
			stilde = stilde*factor;
			if (std::get<2>(time_div[i]) == 0)  // 0 means fixed dividends
				stemp = stemp*factor-std::get<1>(time_div[i]);
			else { // 1 means proportional dividends
				stemp = stemp*factor*(1 - std::get<1>(time_div[i]));
			}
		}
		factor = exp((r - dividend - sigma*sigma / 2)*(T - std::get<0>(time_div[freq]))
			+ sigma*sqrt(T - std::get<0>(time_div[freq]))*normals[it + freq]);
		if (std::get<0>(time_div[freq]) < T) {
				stemp = stemp*factor;
				stilde = stilde*factor;
		}
		ST.push_back(stemp);
		ST_tilde.push_back(stilde);
	}


	if (type == 'c') { //code for call option
		for (int i = 0; i < ST.size(); i++) {
			sum_vals += exp(-r*T)*std::max(ST[i] - k, 0.0);
			sum_deltas += (ST[i] >= k)*exp(-r*T)*(ST_tilde[i] / S0)*proportional_dividends;
		}
	}
	else
	{
		for (int i = 0; i < ST.size(); i++) {
			sum_vals += exp(-r*T)*std::max(k - ST[i], 0.0);
			sum_deltas += -(ST[i]< k)*exp(-r*T)*(ST_tilde[i]/ S0)*proportional_dividends;
		}
	}

	results.push_back(sum_vals / ST.size());
	results.push_back(sum_deltas / ST.size());
	return results;
}

std::vector<double> euoption_disdiv::Control_Variance(int N, char eigen) {
	Random_Number_Generator rg(N * 2);
	std::vector<double> normals;
	//std::vector<double> option_deltas;
	std::vector<double> results;

	if (eigen == 'I') {
		normals = rg.Invese_Transform_Normal();
	}
	else if (eigen == 'B') {
		normals = rg.Box_Muller_Normal();
	}
	else {
		normals = rg.Acceptance_Rejection_Normal();
	}
	int freq = time_div.size() - 1;//frequency of dividends
	double factor;
	double proportional_dividends = 1;
	for (auto ele : time_div) {
		if (std::get<2>(ele) == 1)
			proportional_dividends *= (1 - std::get<1>(ele));
	}
	std::vector<double> ST;
	std::vector<double> ST_tilde;
	std::vector<double> PT;
	std::vector<double> PT_tilde;
	std::vector<double> delta;
	std::vector<double> delta_tilde;
	double sum_vals_cv = 0;
	double sum_deltas_cv = 0;
	//Get ST and ST_tilde
	for (int it = 0; it <= N - freq; it = it + 4) {
		double stemp = S0;
		double stilde = S0;
		for (int i = 1; i <= freq; ++i) {
			factor = exp((r - dividend - sigma*sigma / 2)*(std::get<0>(time_div[i]) - std::get<0>(time_div[i - 1]))
				+ sigma*sqrt(std::get<0>(time_div[i]) - std::get<0>(time_div[i - 1]))*normals[it + i - 1]);
			stilde = stilde*factor;
			if (std::get<2>(time_div[i]) == 0)  // 0 means fixed dividends
				stemp = stemp*factor - std::get<1>(time_div[i]);
			else { // 1 means proportional dividends
				stemp = stemp*factor*(1 - std::get<1>(time_div[i]));
			}
		}
		factor = exp((r - dividend - sigma*sigma / 2)*(T - std::get<0>(time_div[freq]))
			+ sigma*sqrt(T - std::get<0>(time_div[freq]))*normals[it + freq]);
		if (std::get<0>(time_div[freq]) < T) {
			stemp = stemp*factor;
			stilde = stilde*factor;
		}
		ST.push_back(stemp);
		ST_tilde.push_back(stilde);
	}

	//Calculate PT and delta

	if (type == 'c') { //code for call option
		for (int i = 0; i < ST.size(); i++) {
			PT.push_back(exp(-r*T)*std::max(ST[i] - k, 0.0));
			delta.push_back((ST[i] >= k)*exp(-r*T)*(ST_tilde[i] / S0)*proportional_dividends);
		}
	}
	else
	{
		for (int i = 0; i < ST.size(); i++) {
			PT.push_back(exp(-r*T)*std::max(k - ST[i], 0.0));
			delta.push_back(-(ST[i] <= k)*exp(-r*T)*(ST_tilde[i] / S0)*proportional_dividends);
		}
	}
	//Calculate PT_tilde and delta_tilde
	if (type == 'c') { //code for call option
		for (auto it = ST_tilde.begin(); it != ST_tilde.end(); it++) {
			PT_tilde.push_back(exp(-r*T)*std::max((*it) - k, 0.0));
			delta_tilde.push_back(((*it) >= k)*exp(-r*T)*((*it) / S0));
		}
	}
	else
	{
		for (auto it = ST_tilde.begin(); it != ST_tilde.end(); it++) {
			PT_tilde.push_back(exp(-r*T)*std::max(-(*it) + k, 0.0));
			delta_tilde.push_back(-((*it) < k)*exp(-r*T)*((*it) / S0));
		}
	}
	//Use control variate to calculate PT_cv and delta_cv
	double b_pt = central_product(PT_tilde, PT) / central_product(PT_tilde, PT_tilde);
	double b_delta = central_product(delta_tilde, delta) / central_product(delta_tilde, delta_tilde);
	
	double W_pt = 0;
	double W_delta = 0;
	for (int i = 0; i < PT.size(); ++i)
	{
		W_pt += (PT[i] - b_pt*(PT_tilde[i] - BS_price()));
		W_delta += (delta[i] - b_delta*(delta_tilde[i] - BS_delta()));
	}
	double sum = 0;
	for (auto ele : delta_tilde) {
		sum += ele;
	}
	results.push_back(W_pt/ PT.size());
	results.push_back(W_delta / delta.size());
	return results;
}