#ifndef Random_Number_Generator_HPP
#define Random_Number_Generator_HPP
#include<iostream>
#include<vector>
#include<cmath>
#include<math.h>
#include<iomanip>
#include<algorithm>
#define M_PI   3.141592653589793238462643383279502884L;
double normalCDF(double value);
double normalPDF(double value);

class Random_Number_Generator{
private:	
	long long Simulations;
public:
	Random_Number_Generator(long long N);
	Random_Number_Generator(const Random_Number_Generator& new_Ran);
	virtual ~Random_Number_Generator();
	Random_Number_Generator& operator =(const Random_Number_Generator& new_Ran);
	
	void Steps(long long New_N);
	int Steps();

	std::vector<double> Linear_Uniform_Generator();
	std::vector<double> Invese_Transform_Normal();
	std::vector<double> Acceptance_Rejection_Normal();
	std::vector<double> Box_Muller_Normal();
	double Inverse_Normal(double u);
};
#endif