#include "Random_Number_Generator.hpp"

double normalCDF(double value){
	return 0.5*(erf(value / sqrt(2)) + 1);
}
double normalPDF(double value) {
	long double pi = M_PI;
	return exp(-0.5*value*value) / sqrt(2 * pi);
}

Random_Number_Generator::Random_Number_Generator(long long N):Simulations(N){}

Random_Number_Generator::~Random_Number_Generator(){}

Random_Number_Generator& Random_Number_Generator::operator=(const Random_Number_Generator& New_RG) {
	if (this == &New_RG)
		return *this;
	Simulations = New_RG.Simulations;
	return *this;
}

Random_Number_Generator::Random_Number_Generator(const Random_Number_Generator& New_RG):Simulations(New_RG.Simulations){}

int Random_Number_Generator::Steps() {
	return Simulations;
}

void Random_Number_Generator::Steps(long long N) {
	Simulations = N;
}

std::vector<double> Random_Number_Generator::Linear_Uniform_Generator() {
	std::vector<double> Uniform_Numbers;
	long long x = 1;
	long long a = 39373;
	long long k = pow(2, 31) - 1;
	for (int i = 0; i < Simulations;i++) {
		x = (a*x) % k;
		Uniform_Numbers.push_back(double(x) / k);
		
	}
	return Uniform_Numbers;
}

std::vector<double> Random_Number_Generator::Invese_Transform_Normal() {
	std::vector<double> Normal_Distributions;
	std::vector<double> Uniform_Distributions = Linear_Uniform_Generator();
	for (auto it = Uniform_Distributions.begin(); it != Uniform_Distributions.end(); it++) {
		Normal_Distributions.push_back(Inverse_Normal(*it));
	}
	return Normal_Distributions;
}

double Random_Number_Generator::Inverse_Normal(double u) {

	double a0 = 2.50662823884;
	double a1 = -18.61500062529;
	double a2 = 41.39119773534;
	double a3 = -25.44106049637;

	double b0 = -8.47351093090;
	double b1 = 23.08336743743;
	double b2 = -21.06224101826;
	double b3 = 3.13082909833;

	double c0 = 0.3374754822726147;
	double c1 = 0.9761690190917186;
	double c2 = 0.1607979714918209;
	double c3 = 0.0276438810333863;
	double c4 = 0.0038405729373609;
	double c5 = 0.0003951896511919;
	double c6 = 0.0000321767881768;
	double c7 = 0.0000002888167364;
	double c8 = 0.0000003960315187;
	
	double r;
	double y = u - 0.5;
	double x;

	if (abs(y) < 0.42) {
		r = y*y;
		//std::cout << r << '\n';
		x = y*(((a3*r + a2)*r + a1)*r + a0) / ((((b3*r + b2)*r + b1)*r + b0)*r + 1);
		//std::cout << x << '\n';
	}
	else {
		r = u;
		if (y > 0) {
			r = 1 - u;
		}
		r = log(-log(r));
		x = c0 + r*(c1 + r*(c2 + r*(c3 + r*(c4 + r*(c5 + r*(c6 + r*(c7 + r*c8)))))));
		if (y < 0) {
			x = -x;
		}
	}
	return x;
}

std::vector<double> Random_Number_Generator::Acceptance_Rejection_Normal() {
	//remark, should use iterator, think about data structrue first
	std::vector<double> uniforms = Linear_Uniform_Generator();
	std::vector<double>	normals;
	std::vector<double> u_pairs;
	auto it = uniforms.begin();

	while (true) {
		if (std::distance(it, uniforms.end()) <= 2) {
			break;
		}
		double x = -log(*it);
		if ((*(it+1)) > exp(-0.5*pow(x - 1, 2))) {
			it = it + 3; //increase iterator
			continue;
		}
		if (*(it+2) <= 0.5) {
			x = -x;
		}

		normals.push_back(x);
		it = it + 3;
	}
	return normals;
}

std::vector<double> Random_Number_Generator::Box_Muller_Normal() {
	std::vector<double> uniforms = Linear_Uniform_Generator();
	std::vector<double> normals;
	std::vector<double> u_pairs;
	auto it = uniforms.begin();
	
	while (true) {
		if (std::distance(it, uniforms.end()) <= 1) {
			break; //break the loop if too few elements remained
		}
		double u_1 = 2*(*it)-1;
		double u_2 = 2*(*(it + 1))-1;
		double x = pow(u_1,2) + pow(u_2,2);
		if (x > 1) {
			it = it + 2;
			continue;
		}

		double y = sqrt(-2 * log(x) / x);
		normals.push_back(y*u_1);
		normals.push_back(y*u_2);
		it = it + 2;
		
	}
	return normals;
}

